import { React } from 'react';

import './login.css'
// import Logo from '../../../../public/img/Vivo Horizontal Purpura RGB.jpg'
import LoginForm from '../../userSessions/LoginForm/LoginForm';
function Login() {

    return (
        <div className='body-container'>
            
            <LoginForm/>
        </div>
    );
}

export default Login;
